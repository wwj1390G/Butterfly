#ifndef __ADC_H
#define __ADC_H	
#include "STM32F10x.H"

void adc_init(void);

extern unsigned short int adc_value[4];
 
#endif 


