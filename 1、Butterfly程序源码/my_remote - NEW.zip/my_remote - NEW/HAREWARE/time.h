#ifndef __TIME_H
#define __TIME_H
#include "stm32F10x.h"

void TIM4_Init(void);

#endif



